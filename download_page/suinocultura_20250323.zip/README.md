# Sistema de Gestão Suinocultura

Este é um aplicativo Streamlit para gerenciamento de operações de suinocultura. Para executar:

1. Instale as dependências: `pip install -r requirements.txt`
2. Execute o aplicativo: `streamlit run app.py`

Consulte o arquivo `guia_criacao_apk.md` para instruções sobre como criar um APK para Android.