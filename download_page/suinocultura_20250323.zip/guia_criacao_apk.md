# Guia para Criação de APK a partir da Aplicação Streamlit

Este guia fornece instruções sobre como converter a aplicação Streamlit "Sistema de Gestão Suinocultura" em um aplicativo Android (APK) que pode ser instalado em dispositivos móveis.

## Opção 1: Usando WebView (Mais Simples)

A abordagem mais simples é criar um aplicativo Android que use um WebView para mostrar sua aplicação Streamlit hospedada em um servidor.

### Pré-requisitos:
- Android Studio instalado no seu computador
- Conhecimento básico de desenvolvimento Android
- Um servidor hospedando sua aplicação Streamlit (pode ser um serviço como Streamlit Cloud, Heroku, ou um servidor próprio)

### Passos:

1. **Hospedar a aplicação Streamlit**:
   - Faça deploy da sua aplicação Streamlit em um serviço como Streamlit Cloud, Heroku, ou um servidor próprio
   - Certifique-se de que a aplicação está acessível via navegador

2. **Criar um novo projeto Android**:
   - Abra o Android Studio
   - Crie um novo projeto com uma "Empty Activity"
   - Dê o nome "SuinoculturaApp" ao projeto

3. **Configurar permissões no manifesto**:
   - Abra o arquivo `AndroidManifest.xml`
   - Adicione a permissão de internet:
   ```xml
   <uses-permission android:name="android.permission.INTERNET" />
   ```

4. **Criar o layout com WebView**:
   - Abra o arquivo `activity_main.xml`
   - Substitua o conteúdo pelo seguinte:
   ```xml
   <?xml version="1.0" encoding="utf-8"?>
   <RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android"
       xmlns:tools="http://schemas.android.com/tools"
       android:layout_width="match_parent"
       android:layout_height="match_parent"
       tools:context=".MainActivity">

       <WebView
           android:id="@+id/webView"
           android:layout_width="match_parent"
           android:layout_height="match_parent" />

   </RelativeLayout>
   ```

5. **Configurar o WebView na atividade principal**:
   - Abra o arquivo `MainActivity.java` (ou `.kt` se estiver usando Kotlin)
   - Substitua o conteúdo pelo seguinte (versão Java):

   ```java
   package com.example.suinoculturaapp;

   import androidx.appcompat.app.AppCompatActivity;
   import android.os.Bundle;
   import android.webkit.WebSettings;
   import android.webkit.WebView;
   import android.webkit.WebViewClient;

   public class MainActivity extends AppCompatActivity {

       private WebView webView;

       @Override
       protected void onCreate(Bundle savedInstanceState) {
           super.onCreate(savedInstanceState);
           setContentView(R.layout.activity_main);

           webView = findViewById(R.id.webView);
           webView.setWebViewClient(new WebViewClient());
           WebSettings webSettings = webView.getSettings();
           webSettings.setJavaScriptEnabled(true);
           webSettings.setDomStorageEnabled(true);
           webSettings.setBuiltInZoomControls(true);
           webSettings.setDisplayZoomControls(false);
           
           // Carregar a URL da sua aplicação Streamlit
           webView.loadUrl("https://seu-servidor-streamlit.com");
       }

       @Override
       public void onBackPressed() {
           if (webView.canGoBack()) {
               webView.goBack();
           } else {
               super.onBackPressed();
           }
       }
   }
   ```

6. **Criar ícones personalizados**:
   - Use o Asset Studio do Android Studio para criar ícones personalizados
   - Escolha "Image Asset" no menu "Resource Manager"
   - Selecione uma imagem de porco ou o logo da Suinocultura

7. **Construir o APK**:
   - Vá para Build > Build Bundle(s) / APK(s) > Build APK(s)
   - O APK será gerado na pasta `app/build/outputs/apk/debug/`

8. **Instalar o APK**:
   - Transfira o APK para o dispositivo Android
   - Abra o arquivo no dispositivo para instalá-lo
   - Você pode precisar habilitar a instalação de fontes desconhecidas nas configurações do dispositivo

## Opção 2: Usando Streamlit-APK (Mais Avançado)

Uma abordagem mais avançada é usar ferramentas como Buildozer (baseado em Kivy) para empacotar diretamente a aplicação Python.

### Pré-requisitos:
- Linux (Ubuntu recomendado)
- Python 3.7+ instalado
- Conhecimento básico de linha de comando

### Passos:

1. **Instalar dependências**:
   ```bash
   sudo apt update
   sudo apt install -y git zip unzip openjdk-8-jdk python3-pip autoconf libtool pkg-config zlib1g-dev libncurses5-dev libncursesw5-dev libtinfo5 cmake libffi-dev libssl-dev
   pip3 install --user --upgrade Cython==0.29.19 virtualenv
   ```

2. **Instalar Buildozer**:
   ```bash
   pip3 install --user --upgrade buildozer
   ```

3. **Preparar o projeto**:
   - Crie um novo diretório para o projeto mobile:
   ```bash
   mkdir SuinoculturaAPK
   cd SuinoculturaAPK
   ```

4. **Inicializar Buildozer**:
   ```bash
   buildozer init
   ```

5. **Configurar o arquivo buildozer.spec**:
   - Abra o arquivo `buildozer.spec` e faça as seguintes modificações:

   ```
   [app]
   title = Suinocultura
   package.name = suinocultura
   package.domain = org.suinocultura
   source.dir = .
   source.include_exts = py,png,jpg,kv,atlas,csv
   requirements = python3,kivy,streamlit,pandas,numpy,plotly,matplotlib
   orientation = portrait
   osx.python_version = 3
   android.api = 30
   android.minapi = 21
   android.ndk = 23b
   android.sdk = 30
   p4a.bootstrap = sdl2
   ```

6. **Criar um script wrapper Kivy**:
   - Crie um arquivo `main.py` que carregará sua aplicação Streamlit:

   ```python
   import os
   import subprocess
   import threading
   from kivy.app import App
   from kivy.lang import Builder
   from kivy.uix.boxlayout import BoxLayout
   import time

   # Definir o layout da UI Kivy
   Builder.load_string('''
   <StreamlitAppUI>:
       orientation: 'vertical'
       Label:
           text: 'Sistema de Gestão Suinocultura'
           size_hint_y: 0.1
       BoxLayout:
           orientation: 'vertical'
           size_hint_y: 0.9
           Label:
               text: 'A aplicação Streamlit está carregando...'
               id: status_label
   ''')

   class StreamlitAppUI(BoxLayout):
       pass

   class SuinoculturaApp(App):
       def build(self):
           self.ui = StreamlitAppUI()
           # Iniciar o servidor Streamlit em uma thread separada
           threading.Thread(target=self.run_streamlit, daemon=True).start()
           return self.ui
       
       def run_streamlit(self):
           # Aguardar um pouco para a UI ser carregada
           time.sleep(2)
           
           try:
               # Diretório para armazenar dados
               if not os.path.exists('/storage/emulated/0/Suinocultura'):
                   os.makedirs('/storage/emulated/0/Suinocultura')
               
               # Copiar arquivos necessários
               if not os.path.exists('/storage/emulated/0/Suinocultura/app.py'):
                   with open('/storage/emulated/0/Suinocultura/app.py', 'w') as f:
                       f.write(open('app.py').read())
               
               # Iniciar o servidor Streamlit
               os.chdir('/storage/emulated/0/Suinocultura')
               process = subprocess.Popen(
                   ['python', '-m', 'streamlit', 'run', 'app.py', '--server.port', '8501'],
                   stdout=subprocess.PIPE, stderr=subprocess.PIPE
               )
               
               # Atualizar a UI
               self.ui.ids.status_label.text = 'Servidor Streamlit iniciado. Acesse em: http://localhost:8501'
               
               # Monitorar o processo
               while True:
                   line = process.stdout.readline()
                   if not line:
                       break
                   print(line.decode('utf-8').strip())
                   
           except Exception as e:
               self.ui.ids.status_label.text = f'Erro: {str(e)}'

   if __name__ == '__main__':
       SuinoculturaApp().run()
   ```

7. **Construir o APK**:
   ```bash
   buildozer -v android debug
   ```
   
   Este processo pode levar um tempo considerável (30min-1hr) e pode falhar na primeira tentativa.

8. **APK Final**:
   - Se o build for bem-sucedido, o APK estará em `bin/suinocultura-0.1-debug.apk`

## Recomendação Final

Para seu caso específico, recomendo a **Opção 1** (WebView) por ser mais simples e ter maior chance de funcionar corretamente. A opção 2 é significativamente mais complexa e pode exigir ajustes específicos devido à natureza da aplicação Streamlit.

Lembre-se de que a experiência do usuário em um aplicativo móvel pode ser diferente da experiência web, e pode ser necessário fazer alguns ajustes no layout da sua aplicação Streamlit para que ela seja mais responsiva em telas menores.

## Observações Importantes

1. **Banco de Dados**: Se sua aplicação usa dados locais (CSV), você precisará garantir que esses dados sejam transferidos corretamente para o dispositivo móvel ou mudar para um banco de dados que possa ser acessado por rede.

2. **Recursos do Dispositivo**: O acesso a recursos do dispositivo (câmera, GPS, etc.) exigirá código adicional no aplicativo Android.

3. **Manutenção**: Atualizações da aplicação exigirão novas versões do APK.

4. **Opção Simplificada**: Como alternativa mais simples, você pode simplesmente adicionar um atalho para o site da aplicação Streamlit na tela inicial do dispositivo Android sem precisar criar um APK.