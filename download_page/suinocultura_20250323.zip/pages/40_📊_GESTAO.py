import streamlit as st

st.set_page_config(page_title="GESTÃO", page_icon="📊", layout="wide")

# Verificar autenticação
if "authenticated" not in st.session_state or not st.session_state.authenticated:
    st.warning("Você precisa estar autenticado para acessar esta página.")
    st.stop()

st.title("🔹 GESTÃO")
st.write("Acesse as funcionalidades de gestão através do menu lateral")

st.write("""
## Módulos de Gestão
         
Esta seção contém ferramentas para a administração geral do sistema, incluindo:

- Administração do Sistema
- Gestão de Colaboradores
- Cadastro de Animais
- Gestão de Baias
- Relatórios Gerais

Navegue para as páginas específicas a partir do menu lateral.
""")

# Adicionar alguns cards para acesso rápido
col1, col2, col3 = st.columns(3)

with col1:
    st.info("""
    ### Administração
    Configurações gerais do sistema e controle de acesso
    """)
    
with col2:
    st.info("""
    ### Colaboradores
    Cadastro e gestão de colaboradores
    """)
    
with col3:
    st.info("""
    ### Relatórios
    Geração de relatórios e estatísticas
    """)