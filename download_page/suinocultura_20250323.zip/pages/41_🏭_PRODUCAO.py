import streamlit as st

st.set_page_config(page_title="PRODUÇÃO", page_icon="🐖", layout="wide")

# Verificar autenticação
if "authenticated" not in st.session_state or not st.session_state.authenticated:
    st.warning("Você precisa estar autenticado para acessar esta página.")
    st.stop()

st.title("🔹 PRODUÇÃO")
st.write("Acesse as funcionalidades de produção através do menu lateral")

st.write("""
## Módulos de Produção
         
Esta seção contém ferramentas para o gerenciamento do ciclo reprodutivo e produtivo, incluindo:

- Ciclo Reprodutivo
- Gestação
- Inseminação
- Maternidade
- Desmame
- Creche

Navegue para as páginas específicas a partir do menu lateral.
""")

# Adicionar alguns cards para acesso rápido
col1, col2, col3 = st.columns(3)

with col1:
    st.info("""
    ### Ciclo Reprodutivo
    Acompanhamento do ciclo reprodutivo das matrizes
    """)
    
with col2:
    st.info("""
    ### Inseminação
    Registro e acompanhamento de inseminações
    """)
    
with col3:
    st.info("""
    ### Maternidade
    Gestão de leitões e matrizes na maternidade
    """)