import streamlit as st

st.set_page_config(page_title="RELATÓRIOS", page_icon="📊", layout="wide")

# Verificar autenticação
if "authenticated" not in st.session_state or not st.session_state.authenticated:
    st.warning("Você precisa estar autenticado para acessar esta página.")
    st.stop()

st.title("🔹 RELATÓRIOS")
st.write("Acesse os relatórios gerenciais através do menu lateral")

st.write("""
## Módulos de Relatórios
         
Esta seção contém relatórios gerenciais e análises de desempenho, incluindo:

- Relatórios de Produção
- Relatórios de Reprodução
- Indicadores de Desempenho
- Análises Financeiras
- Estatísticas do Plantel

Navegue para os relatórios específicos a partir do menu lateral.
""")

# Adicionar alguns cards para acesso rápido
col1, col2, col3 = st.columns(3)

with col1:
    st.info("""
    ### Relatórios de Produção
    Análises de produtividade e eficiência
    """)
    
with col2:
    st.info("""
    ### Indicadores Reprodutivos
    Análise do desempenho reprodutivo do plantel
    """)
    
with col3:
    st.info("""
    ### Análises Financeiras
    Custos, receitas e indicadores econômicos
    """)