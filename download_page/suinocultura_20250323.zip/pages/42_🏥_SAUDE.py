import streamlit as st

st.set_page_config(page_title="SAÚDE", page_icon="💉", layout="wide")

# Verificar autenticação
if "authenticated" not in st.session_state or not st.session_state.authenticated:
    st.warning("Você precisa estar autenticado para acessar esta página.")
    st.stop()

st.title("🔹 SAÚDE")
st.write("Acesse as funcionalidades de saúde animal através do menu lateral")

st.write("""
## Módulos de Saúde
         
Esta seção contém ferramentas para o gerenciamento da saúde do rebanho, incluindo:

- Vacinação
- Mortalidade
- Monitoramento de Peso e Idade
- Tratamentos e Medicações
- Detecção de Cio
- Rufia

Navegue para as páginas específicas a partir do menu lateral.
""")

# Adicionar alguns cards para acesso rápido
col1, col2, col3 = st.columns(3)

with col1:
    st.info("""
    ### Vacinação
    Controle e registro de vacinações
    """)
    
with col2:
    st.info("""
    ### Mortalidade
    Registro e análise de mortalidade
    """)
    
with col3:
    st.info("""
    ### Peso e Idade
    Monitoramento de desenvolvimento dos animais
    """)