import streamlit as st

st.set_page_config(page_title="DESENVOLVIMENTO", page_icon="📈", layout="wide")

# Verificar autenticação
if "authenticated" not in st.session_state or not st.session_state.authenticated:
    st.warning("Você precisa estar autenticado para acessar esta página.")
    st.stop()

st.title("🔹 DESENVOLVIMENTO")
st.write("Acesse as funcionalidades de desenvolvimento através do menu lateral")

st.write("""
## Módulos de Desenvolvimento
         
Esta seção contém ferramentas para o gerenciamento do desenvolvimento dos animais, incluindo:

- Sistema de Recria
- Seleção de Leitoas
- Nutrição Animal
- Desempenho Zootécnico
- Análise de Conversão Alimentar

Navegue para as páginas específicas a partir do menu lateral.
""")

# Adicionar alguns cards para acesso rápido
col1, col2 = st.columns(2)

with col1:
    st.info("""
    ### Sistema de Recria
    Gestão completa do sistema de recria com formação de lotes, 
    monitoramento de peso, alimentação e medicação
    """)
    
with col2:
    st.info("""
    ### Seleção de Leitoas
    Processo de seleção e descarte de leitoas para reprodução
    """)